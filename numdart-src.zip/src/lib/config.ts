export const PLAY_URL = 'https://play.google.com/store/apps/details?id=com.yunusdeniz.numdart';
/** Static site on Vercel (see /site). Update if the deployed domain differs. */
export const SITE_URL = 'https://numdart.vercel.app';
export const PRIVACY_URL = {
  tr: `${SITE_URL}/gizlilik.html`,
  en: `${SITE_URL}/privacy.html`,
};
export const CONTACT_EMAIL = 'yundnz@gmail.com';

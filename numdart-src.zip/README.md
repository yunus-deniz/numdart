# Numdart

Sayı bulmaca oyunu. **Tahta Temizleme** (ana mod, sınırsız seviye) + **🎯 Günlük Klasik** (6 sayı, bir hedef).
Tek doğru kaynak: [`NUMDART-SPEC.md`](NUMDART-SPEC.md).

## Durum: v1.0 (kapalı test sürümü) hazır

Spec'in 9. bölümündeki v1.0 kapsamı tamam:

- Tahta Temizleme: tersten üretilen seviyeler (her seviyenin çözümü garanti), sınırsız seviye, seviye numarası = seed, toplama → çarpma (31+) → çıkarma ve buzlu taşlar (51+), canlı toplam kapsülü, fazla gelince mercan + sallanma + hata titreşimi, kilitlenme tespiti, seviyede 1 kez ücretsiz "3 hamle geri al", ipucu, baştan başla. İlk 30 seviyenin eğrisi elle ayarlı; Seviye 1–3 eğitimi oyunun içinde.
- Günlük Klasik: yerel tarihten deterministik bulmaca (mulberry32 + tarih hash'i), haftalık zorluk profili, cihaz içi çözücü, yıldızlar, tam isabette 0,4 sn sonra otomatik zafer, seri (bitiren devam eder), telefon tarihini geri alma koruması, iki kademeli ipucu, en iyi çözümü gör, emoji paylaşımı, 15 saniyelik oynatarak eğitim.
- İstatistikler, ayarlar (ses, titreşim, tema, dil), TR + EN, açık/koyu tema, Space Grotesk + Plus Jakarta Sans, ses efektleri, titreşim, ekran okuyucu etiketleri, 480dp genişlik sınırı, yazı büyütme sınırı (1,15).
- **Reklam ve satın alma yok** (spec gereği). `src/lib/rewards.ts` şimdilik her ödülü direkt veriyor; v1.0.1'de AdMob buraya bağlanacak.

Henüz yapılmayanlar (spec'e göre sonraki sürümler): Katman + Tortu (v1.0.1), AdMob + UMP + RevenueCat (v1.0.1), 20:30 hatırlatma bildirimi (v1.0.1), Arapça/Almanca/İspanyolca/Fransızca (v1.1).

## Klasörler

```
src/engine/     Oyun motorları (saf TypeScript, testli)
  rng.ts          mulberry32 + hash
  dates.ts        yerel tarih, bulmaca numarası (UTC normalize)
  classic.ts      Günlük Klasik: üretici, çözücü, puan, paylaşım metni
  board.ts        Tahta Temizleme: seviye üretici, çözücü, kurallar
src/app/        Ekranlar (expo-router): index (tahta), daily, stats, settings
src/components/ Taş, kart, hedef kuyruğu, konfeti, ortak düğmeler
src/lib/        MMKV kayıt, tema, ses/titreşim, ödül kapısı, ayarlar
src/i18n/       TR + EN metinler
tests/          1.000 günlük bulmaca + 500 seviye testi
assets/         İkon, splash, sesler
site/           Vercel'e yüklenecek statik site (gizlilik TR/EN, app-ads.txt)
store/          Play mağaza metinleri, ikon 512, öne çıkan grafik, ekran görüntüleri
```

## Bilgisayarda çalıştırma (Windows)

```bash
npm install
npm test            # motor testleri (1.000 gün + 500 seviye)
npm run typecheck
npx expo start --web   # tarayıcıda hızlı önizleme
```

Projede native modüller (MMKV, Reanimated) var, bu yüzden **Expo Go ile çalışmaz**. Telefonda denemek için aşağıdaki EAS "preview" derlemesini kullan.

## Derleme ve Play'e yükleme (EAS, bulutta)

1. Expo hesabı aç (ücretsiz): https://expo.dev/signup
2. Proje klasöründe:
   ```bash
   npx eas-cli@latest login
   npx eas-cli@latest init          # projeyi Expo hesabına bağlar (app.json'a projectId ekler)
   ```
3. Telefonda denemek için APK:
   ```bash
   npx eas-cli@latest build -p android --profile preview
   ```
   Bitince verilen bağlantıdan APK'yı telefona indirip kur.
4. Play için AAB:
   ```bash
   npx eas-cli@latest build -p android --profile production
   ```
   EAS ilk seferde "Generate a new Android Keystore?" diye sorar → **Yes**. Anahtar Expo hesabında güvenle saklanır.
5. Play Console (yundnz@gmail.com, kişisel hesap) → Uygulama oluştur → "Numdart: Sayı Bulmaca Oyunu" → Oyun, Ücretsiz.
6. Test → Kapalı test → Yeni sürüm → AAB'yi yükle. Mağaza metinleri ve formlar için `store/MAGAZA-METINLERI.md`.
7. Her yeni yüklemede `app.json` içindeki `android.versionCode` değerini 1 artır (1 → 2 → 3).

## Statik site (Vercel)

`site/` klasörünü Vercel'e ayrı bir proje olarak yükle (Framework: Other, Root: `site`). Alan adı `numdart.vercel.app` dışında bir şey olursa `src/lib/config.ts` içindeki `SITE_URL` değerini güncelle. AdMob gelince `site/app-ads.txt` içine yayıncı kimliği yazılacak.
